'use client';

import AdBanner from '@/components/ads/AdBanner';
import Calculator from '@/components/calculator/Calculator';
import UnitConverter from '@/components/converter/UnitConverter';
import { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'calculator' | 'converter'>('calculator');
  const { t } = useTranslation();
  const homeText = t('home');

  return (
    <main className="min-h-screen flex flex-col">
      <AdBanner position="top" />

      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('calculator')}
              className={`px-6 py-3 rounded-btn font-medium transition-all ${
                activeTab === 'calculator'
                  ? 'bg-primary text-white'
                  : 'bg-white border border-border text-text-secondary hover:bg-bg-tertiary'
              }`}
            >
              {homeText.calculator}
            </button>
            <button
              onClick={() => setActiveTab('converter')}
              className={`px-6 py-3 rounded-btn font-medium transition-all ${
                activeTab === 'converter'
                  ? 'bg-primary text-white'
                  : 'bg-white border border-border text-text-secondary hover:bg-bg-tertiary'
              }`}
            >
              {homeText.unitConverter}
            </button>
          </div>
        </div>

        {activeTab === 'calculator' ? <Calculator /> : <UnitConverter />}
      </div>

      <AdBanner position="bottom" />
    </main>
  );
}
