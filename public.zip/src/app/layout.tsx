import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import Navbar from '@/components/ui/Navbar';
import CookieConsent from '@/components/ui/CookieConsent';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Calculator World - Free Online Calculator & Unit Converter',
  description: 'A minimalist, powerful calculator app with scientific calculations, unit conversion, and multi-language support. Free to use for everyone.',
  keywords: 'calculator, unit converter, scientific calculator, online calculator, free calculator',
  authors: [{ name: 'Calculator World' }],
  openGraph: {
    title: 'Calculator World - Free Online Calculator',
    description: 'Minimalist, powerful calculator with scientific calculations and unit conversion.',
    type: 'website',
    locale: 'en_US',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Calculator World',
    description: 'Minimalist, powerful calculator with scientific calculations and unit conversion.',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#5B9BD5" />
      </head>
      <body className={inter.className}>
        <LanguageProvider>
          <Navbar />
          {children}
          <CookieConsent />
        </LanguageProvider>
      </body>
    </html>
  );
}
